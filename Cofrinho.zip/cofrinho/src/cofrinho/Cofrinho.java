package cofrinho;

import java.util.ArrayList;

class Cofrinho {
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();
    }

    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);
        System.out.println("Moeda adicionada ao cofrinho: " + moeda.getNome());
    }

    public void removerMoeda(String nomeMoeda, double valor) {
        Moeda moedaRemovida = null;

        for (int i = 0; i < moedas.size(); i++) {
            Moeda moeda = moedas.get(i);
            if (moeda.getNome().equalsIgnoreCase(nomeMoeda) && Math.abs(moeda.getValor() - valor) < 0.0001) {
                moedaRemovida = moeda;
                break;
            }
        }

        if (moedaRemovida != null) {
            moedas.remove(moedaRemovida);
            System.out.println("Moeda removida do cofrinho: " + moedaRemovida.getNome() + " - Valor: " + moedaRemovida.getValor());
        } else {
            System.out.println("Moeda não encontrada no cofrinho.");
        }
    }

    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
        } else {
            System.out.println("Moedas no cofrinho:");
            for (Moeda moeda : moedas) {
                System.out.println(moeda.getNome() + " - Valor: " + moeda.getValor());
            }
        }
    }

    public double calcularTotalEmReal() {
        double total = 0.0;
        for (Moeda moeda : moedas) {
            if (moeda instanceof Real) {
                total += moeda.getValor();
            } else if (moeda instanceof Dolar) {
                total += moeda.getValor() * 4.8; //   1 Dolar vale 4,80 Reais
            } else if (moeda instanceof Euro) {
                total += moeda.getValor() * 5.38; //  1 Euro vale 5,83 Reais
            }
        }
        return total;
    }
}