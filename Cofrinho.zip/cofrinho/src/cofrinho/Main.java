package cofrinho;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Cofrinho cofrinho = new Cofrinho();
        Scanner scanner = new Scanner(System.in);

        int opcao = 0;
        while (opcao != 5) {
            System.out.println("\nMenu:");
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listar moedas");
            System.out.println("4. Calcular total em Reais");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Digite o valor da moeda: ");
                    double valor = scanner.nextDouble();
                    scanner.nextLine(); // Limpa o buffer do scanner

                    System.out.println("Selecione o tipo de moeda:");
                    System.out.println("1. Real");
                    System.out.println("2. Dolar");
                    System.out.println("3. Euro");
                    int tipoMoeda = scanner.nextInt();
                    Moeda moeda = null;
                    switch (tipoMoeda) {
                        case 1:
                            moeda = new Real(valor);
                            break;
                        case 2:
                            moeda = new Dolar(valor);
                            break;
                        case 3:
                            moeda = new Euro(valor);
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                    if (moeda != null) {
                        cofrinho.adicionarMoeda(moeda);
                    }
                    break;
                case 2:
                    System.out.println("Selecione o tipo de moeda:");
                    System.out.println("1. Real");
                    System.out.println("2. Dolar");
                    System.out.println("3. Euro");
                    int tipoMoedaRemover = scanner.nextInt();
                    String nomeMoedaRemover = "";
                    switch (tipoMoedaRemover) {
                        case 1:
                            nomeMoedaRemover = "Real";
                            break;
                        case 2:
                            nomeMoedaRemover = "Dolar";
                            break;
                        case 3:
                            nomeMoedaRemover = "Euro";
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                    if (!nomeMoedaRemover.isEmpty()) {
                        System.out.print("Digite o valor da moeda a ser removida: ");
                        double valorMoedaRemover = scanner.nextDouble();
                        cofrinho.removerMoeda(nomeMoedaRemover, valorMoedaRemover);
                    }
                    break;
                case 3:
                    cofrinho.listarMoedas();
                    break;
                case 4:
                    double total = cofrinho.calcularTotalEmReal();
                    System.out.println("Total em Reais no cofrinho: " + total);
                    break;
                case 5:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }

        scanner.close();
    }
}
