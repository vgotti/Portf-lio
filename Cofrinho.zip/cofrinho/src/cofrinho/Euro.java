package cofrinho;

class Euro extends Moeda {
    public Euro(double valor) {
        super(valor);
    }

    public String getNome() {
        return "Euro";
    }
}