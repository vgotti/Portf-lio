package cofrinho;

class Dolar extends Moeda {
    public Dolar(double valor) {
        super(valor);
    }

    public String getNome() {
        return "Dolar";
    }
}